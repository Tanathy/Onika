import sys
from contextlib import contextmanager

def info(msg: str):
    print(f"[INFO] {msg}")

def warning(msg: str):
    print(f"[WARNING] {msg}", file=sys.stderr)

def error(msg: str):
    print(f"[ERROR] {msg}", file=sys.stderr)

def success(msg: str):
    print(f"[SUCCESS] {msg}")

@contextmanager
def progress_context(msg: str = None, total: int = None, desc: str = None, unit: str = None, **kwargs):
    description = desc or msg or "Processing"
    print(f"[START] {description}...")
    
    class DummyProgressBar:
        def update(self, n=1):
            pass
            
    try:
        yield DummyProgressBar()
    finally:
        print(f"[END] {description}")
