from pathlib import Path
from typing import Dict, Optional
from system.diffusion.base import DiffusionModelWrapper
from system.diffusion.sd_legacy import SDLegacyWrapper
from system.diffusion.sdxl import SDXLWrapper
from system.diffusion.sd3 import SD3Wrapper
from system.diffusion.detector import detect_model_type
from system.log import info, error

class ModelManager:
    def __init__(self):
        self.loaded_model: Optional[DiffusionModelWrapper] = None

    def load_model(self, model_path: Path, device: str = "cuda") -> Optional[DiffusionModelWrapper]:
        if self.loaded_model:
            self.loaded_model.unload()
            self.loaded_model = None

        if not model_path.exists():
            error(f"Model path does not exist: {model_path}")
            return None

        m_type = detect_model_type(model_path)
        info(f"Detected model type: {m_type}")

        if m_type == "sd3":
            self.loaded_model = SD3Wrapper(model_path)
        elif m_type == "sdxl":
            self.loaded_model = SDXLWrapper(model_path)
        elif m_type == "sd_legacy":
            self.loaded_model = SDLegacyWrapper(model_path)
        else:
            # Fallback or error
            # Try legacy if unknown
            warning(f"Unknown model type, trying SD Legacy fallback.")
            self.loaded_model = SDLegacyWrapper(model_path)

        if self.loaded_model:
            try:
                self.loaded_model.load(device)
            except Exception as e:
                error(f"Failed to load model: {e}")
                self.loaded_model = None
        
        return self.loaded_model

    def unload_current(self):
        if self.loaded_model:
            self.loaded_model.unload()
            self.loaded_model = None
