import torch
from pathlib import Path
from typing import Any, Dict
from diffusers import StableDiffusion3Pipeline
from system.diffusion.base import DiffusionModelWrapper
from system.log import info, error

class SD3Wrapper(DiffusionModelWrapper):
    def __init__(self, model_path: Path, config: Dict[str, Any] = None):
        super().__init__(model_path, config)
        self.model_type = "sd3" # Covers SD3 and SD3.5

    def load(self, device: str = "cuda"):
        info(f"Loading SD3/SD3.5 model from {self.model_path}...")
        try:
            # SD3 models can be large, so we might want to enable cpu offload if needed, 
            # but for now we stick to the requested device.
            # SD3 often requires T5, CLIP-G, CLIP-L. Single file loading handles this if embedded.
            self.pipeline = StableDiffusion3Pipeline.from_single_file(
                str(self.model_path),
                torch_dtype=torch.float16 if device == "cuda" else torch.float32,
                use_safetensors=True if self.model_path.suffix == ".safetensors" else False
            )
            self.pipeline.to(device)
            info(f"Model {self.model_path.name} loaded successfully on {device}.")
        except Exception as e:
            error(f"Failed to load SD3 model: {e}")
            raise e

    def unload(self):
        if self.pipeline:
            del self.pipeline
            self.pipeline = None
            torch.cuda.empty_cache()
            info("Model unloaded.")

    def get_info(self) -> Dict[str, Any]:
        return {
            "name": self.model_path.name,
            "type": self.model_type,
            "path": str(self.model_path)
        }
