from pathlib import Path
from safetensors.torch import load_file
from system.log import warning

def detect_model_type(model_path: Path) -> str:
    """
    Detects if a model is SD1.5/2.0 or SDXL based on safetensors keys.
    Returns 'sd_legacy', 'sdxl', or 'unknown'.
    """
    if model_path.suffix != ".safetensors":
        # Fallback for ckpt: assume legacy if small, xl if huge? 
        # Or just return unknown and let user specify.
        # For now, let's assume legacy for non-safetensors as SDXL is mostly safetensors.
        return "sd_legacy"

    try:
        # We only need to peek at keys, but load_file loads tensors. 
        # safetensors.safe_open is better for just keys.
        from safetensors import safe_open
        
        with safe_open(model_path, framework="pt", device="cpu") as f:
            keys = f.keys()
            
            # SD3 specific keys
            # SD3 uses a transformer backbone, often has 'model.diffusion_model.joint_blocks...' or 'transformer.transformer_blocks'
            # A strong indicator is 'mmdit' related keys or 'text_encoder_3' (T5) if bundled.
            # Checking for 'model.diffusion_model.joint_blocks' is a good bet for MM-DiT.
            if any("model.diffusion_model.joint_blocks" in k for k in keys_list) or \
               any("transformer.transformer_blocks" in k for k in keys_list):
                return "sd3"

            # SDXL specific keys
            # SDXL usually has 'conditioner.embedders.0...' or 'te_...' depending on format
            # But a strong indicator is the presence of two text encoders or specific UNet config.
            # SDXL UNet usually has 'model.diffusion_model.input_blocks.7...' which goes up to 8 for SDXL?
            # A simpler check: SDXL has 'conditioner' key often in refiners, or 'text_encoder_2'.
            
            keys_list = list(keys)
            if any("conditioner.embedders.1" in k for k in keys_list) or \
               any("text_encoder_2" in k for k in keys_list):
                return "sdxl"
            
            # Check for SD 1.5 / 2.0
            # They usually have 'cond_stage_model' or 'first_stage_model'
            if any("cond_stage_model" in k for k in keys_list) or \
               any("first_stage_model" in k for k in keys_list):
                return "sd_legacy"
                
            # Fallback: Check tensor shapes if keys are ambiguous (rare)
            
    except Exception as e:
        warning(f"Could not detect model type for {model_path}: {e}")
    
    return "unknown"
