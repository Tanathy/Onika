from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, Optional

class DiffusionModelWrapper(ABC):
    def __init__(self, model_path: Path, config: Optional[Dict[str, Any]] = None):
        self.model_path = model_path
        self.config = config or {}
        self.pipeline = None
        self.model_type = "unknown"

    @abstractmethod
    def load(self, device: str = "cuda"):
        """Load the model into memory."""
        pass

    @abstractmethod
    def unload(self):
        """Unload the model from memory."""
        pass

    @abstractmethod
    def get_info(self) -> Dict[str, Any]:
        """Return information about the model."""
        pass
