from pathlib import Path
from typing import List, Dict, Any, Optional
import os
from system.log import info, error

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}

class DatasetManager:
    def __init__(self, root_path: Path):
        self.root_path = root_path
        # We'll resolve this dynamically or from config, but for now let's assume standard structure
        # or allow updating it.
        self.dataset_relative_path = Path("project/dataset")

    @property
    def dataset_path(self) -> Path:
        return self.root_path / self.dataset_relative_path

    def get_images(self) -> List[Dict[str, Any]]:
        if not self.dataset_path.exists():
            return []
        
        images = []
        try:
            # Scan directory
            for f in self.dataset_path.iterdir():
                if f.is_file() and f.suffix.lower() in IMAGE_EXTENSIONS:
                    txt_path = f.with_suffix(".txt")
                    has_caption = txt_path.exists()
                    caption = ""
                    if has_caption:
                        try:
                            caption = txt_path.read_text(encoding="utf-8").strip()
                        except Exception:
                            pass
                    
                    images.append({
                        "name": f.name,
                        "path": str(f), # Absolute path might be needed for local tools, but for API maybe relative?
                        # For UI serving, we might need a static mount or base64. 
                        # Let's return relative path to root for now.
                        "relative_path": str(f.relative_to(self.root_path)),
                        "caption": caption,
                        "has_caption": has_caption
                    })
        except Exception as e:
            error(f"Error scanning dataset: {e}")
            
        return images

    def update_caption(self, image_name: str, new_caption: str) -> bool:
        # Security check: prevent directory traversal
        if ".." in image_name or "/" in image_name or "\\" in image_name:
            error(f"Invalid image name: {image_name}")
            return False

        image_path = self.dataset_path / image_name
        # We check if the image exists to ensure we are tagging a valid file
        # But strictly speaking, we just need to write the txt file.
        # Let's check if image exists to be safe.
        if not image_path.exists():
            # Try checking if it's just the stem provided or full name
            # The API should provide full name including extension
            return False
        
        txt_path = image_path.with_suffix(".txt")
        try:
            txt_path.write_text(new_caption, encoding="utf-8")
            return True
        except Exception as e:
            error(f"Failed to save caption for {image_name}: {e}")
            return False
