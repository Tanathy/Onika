import sys
from pathlib import Path

# Add project root to sys.path to allow imports from 'system'
ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

import uvicorn
import threading
import webview
from system.config_manager import load_config
from system import coordinator_settings as cs
from system.log import info, error
from system.api import init_app

def start_server(app, host, port):
    uvicorn.run(app, host=host, port=port)

def main():
    if len(sys.argv) < 2:
        error("Root path not provided.")
        sys.exit(1)

    root_path = Path(sys.argv[1])
    info(f"Starting Onika system in {root_path}")

    # Load configuration
    load_config(root_path)

    # Update context with real root path
    from system.context import DATASET_MANAGER
    DATASET_MANAGER.root_path = root_path

    # Initialize API
    app = init_app(root_path)

    # Get host and port from settings
    host = cs.SETTINGS.get("host", "127.0.0.1")
    port = cs.SETTINGS.get("port", 7860)
    url = f"http://{host}:{port}"

    info(f"Starting server at {url}")
    
    # Start server in thread
    t = threading.Thread(target=start_server, args=(app, host, port), daemon=True)
    t.start()
    
    # Start webview
    try:
        webview.create_window("Onika Trainer", url)
        webview.start()
    except Exception as e:
        error(f"Failed to start webview: {e}")
        # Keep main thread alive if webview fails
        t.join()

if __name__ == "__main__":
    main()
