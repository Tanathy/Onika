from system.diffusion.manager import ModelManager
from system.dataset.manager import DatasetManager
from system.training.manager import TrainingManager
from pathlib import Path

# Global runtime context
MODEL_MANAGER = ModelManager()
# We need to initialize this with root path, but context is imported early.
# We can initialize it lazily or set it later.
# For simplicity, let's instantiate it, but we need to set root_path.
# We'll assume entry.py sets it.
DATASET_MANAGER = DatasetManager(Path(".")) 
TRAINING_MANAGER = TrainingManager()