import torch

class TextEncoderHandler:
    def __init__(self, model_type, device):
        self.model_type = model_type
        self.device = device
        self.tokenizers = []
        self.text_encoders = []
    
    def load_from_pipeline(self, pipeline):
        if self.model_type == "sdxl":
            self.tokenizers = [pipeline.tokenizer, pipeline.tokenizer_2]
            self.text_encoders = [pipeline.text_encoder, pipeline.text_encoder_2]
        elif self.model_type == "sd3":
            # SD3 has up to 3 text encoders. 
            # pipeline.tokenizer, pipeline.tokenizer_2, pipeline.tokenizer_3
            # pipeline.text_encoder, pipeline.text_encoder_2, pipeline.text_encoder_3
            self.tokenizers = [pipeline.tokenizer, pipeline.tokenizer_2]
            self.text_encoders = [pipeline.text_encoder, pipeline.text_encoder_2]
            if hasattr(pipeline, "tokenizer_3") and pipeline.tokenizer_3 is not None:
                self.tokenizers.append(pipeline.tokenizer_3)
                self.text_encoders.append(pipeline.text_encoder_3)
        else:
            self.tokenizers = [pipeline.tokenizer]
            self.text_encoders = [pipeline.text_encoder]
            
    def encode(self, prompts):
        if self.model_type == "sdxl":
            return self._encode_sdxl(prompts)
        elif self.model_type == "sd3":
            return self._encode_sd3(prompts)
        else:
            return self._encode_legacy(prompts)

    def _encode_sd3(self, prompts):
        # Simplified SD3 encoding
        # SD3 uses pooled embeddings from CLIP-L and CLIP-G, and T5 embeddings
        # This is a complex implementation in diffusers.
        # For now, we will use a simplified approach or just return what's needed.
        # Ideally we call pipeline.encode_prompt but that might not be easily accessible if we decomposed it.
        
        # Placeholder: SD3 training requires specific encoding handling.
        # We will return empty for now to prevent crash, but this needs full implementation.
        return {
            "encoder_hidden_states": torch.zeros((len(prompts), 77, 4096), device=self.device), # Dummy
            "pooled_prompt_embeds": torch.zeros((len(prompts), 2048), device=self.device) # Dummy
        }

    def _encode_legacy(self, prompts):
        tokenizer = self.tokenizers[0]
        text_encoder = self.text_encoders[0]
        
        text_inputs = tokenizer(
            prompts,
            padding="max_length",
            max_length=tokenizer.model_max_length,
            truncation=True,
            return_tensors="pt",
        )
        text_input_ids = text_inputs.input_ids.to(self.device)
        
        prompt_embeds = text_encoder(text_input_ids)[0]
        return {"encoder_hidden_states": prompt_embeds}

    def _encode_sdxl(self, prompts):
        prompt_embeds_list = []
        pooled_prompt_embeds = None
        
        for i, (tokenizer, text_encoder) in enumerate(zip(self.tokenizers, self.text_encoders)):
            text_inputs = tokenizer(
                prompts,
                padding="max_length",
                max_length=tokenizer.model_max_length,
                truncation=True,
                return_tensors="pt",
            )
            text_input_ids = text_inputs.input_ids.to(self.device)
            
            # We need output_hidden_states=True
            prompt_embeds = text_encoder(
                text_input_ids,
                output_hidden_states=True,
            )
            
            # SDXL uses hidden_states[-2]
            # We assume the text encoder output has hidden_states
            hidden_states = prompt_embeds.hidden_states[-2]
            prompt_embeds_list.append(hidden_states)
            
            if i == 1:
                # Pooled output from 2nd encoder
                pooled_prompt_embeds = prompt_embeds.text_embeds
        
        prompt_embeds = torch.concat(prompt_embeds_list, dim=-1)
        
        return {
            "encoder_hidden_states": prompt_embeds,
            "pooled_prompt_embeds": pooled_prompt_embeds,
            "add_text_embeds": pooled_prompt_embeds # SDXL uses this for time ids usually
        }
