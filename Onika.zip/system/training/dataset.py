import torch
from torch.utils.data import Dataset
from pathlib import Path
from PIL import Image
from torchvision import transforms
import random
from typing import List, Dict, Any

class ImageCaptionDataset(Dataset):
    def __init__(self, dataset_path: str, resolution: int):
        self.dataset_path = Path(dataset_path)
        self.resolution = resolution
        self.image_paths = []
        self.captions = []
        
        # Load images and captions
        exts = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
        if self.dataset_path.exists():
            for f in self.dataset_path.iterdir():
                if f.is_file() and f.suffix.lower() in exts:
                    self.image_paths.append(f)
                    txt_path = f.with_suffix(".txt")
                    if txt_path.exists():
                        try:
                            self.captions.append(txt_path.read_text(encoding="utf-8").strip())
                        except:
                            self.captions.append("")
                    else:
                        self.captions.append("")
        
        print(f"Loaded {len(self.image_paths)} images from {dataset_path}")

        self.transforms = transforms.Compose([
            transforms.Resize(resolution, interpolation=transforms.InterpolationMode.BILINEAR),
            transforms.CenterCrop(resolution),
            transforms.ToTensor(),
            transforms.Normalize([0.5], [0.5]),
        ])

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        caption = self.captions[idx]
        
        try:
            image = Image.open(img_path).convert("RGB")
            # Simple caching or bucketing could be added here later
            image = self.transforms(image)
        except Exception as e:
            print(f"Error loading {img_path}: {e}")
            # Return a dummy tensor
            image = torch.zeros((3, self.resolution, self.resolution))
            
        return {
            "pixel_values": image,
            "caption": caption
        }
