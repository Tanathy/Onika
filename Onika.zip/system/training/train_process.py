import argparse
import json
import sys
import time
import os
import math
from pathlib import Path
from typing import Optional

import torch
import torch.nn.functional as F
from accelerate import Accelerator
from accelerate.utils import ProjectConfiguration, set_seed
from diffusers import (
    AutoencoderKL,
    DDPMScheduler,
    StableDiffusionPipeline,
    StableDiffusionXLPipeline,
    StableDiffusion3Pipeline,
    UNet2DConditionModel,
)
from diffusers.optimization import get_scheduler
from transformers import AutoTokenizer, PretrainedConfig

# Add project root to sys.path
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from system.training.schema import TrainingConfig
from system.training.dataset import ImageCaptionDataset
from system.training.text_encoder import TextEncoderHandler
from system.log import info, error, success, warning

def import_model_class(model_type: str):
    if model_type == "sdxl":
        return StableDiffusionXLPipeline
    elif model_type == "sd_legacy":
        return StableDiffusionPipeline
    elif model_type == "sd3":
        return StableDiffusion3Pipeline
    return StableDiffusionPipeline

def compute_time_ids(original_size, target_size, crops_coords_top_left, device, dtype):
    # Adapted from diffusers SDXL training script
    add_time_ids = list(original_size + crops_coords_top_left + target_size)
    add_time_ids = torch.tensor([add_time_ids], dtype=dtype, device=device)
    return add_time_ids

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    args = parser.parse_args()
    
    try:
        with open(args.config, "r") as f:
            config_data = json.load(f)
        config = TrainingConfig(**config_data)
    except Exception as e:
        error(f"Failed to load config: {e}")
        sys.exit(1)
        
    # Initialize Accelerator
    accelerator = Accelerator(
        gradient_accumulation_steps=config.gradient_accumulation_steps,
        mixed_precision=config.mixed_precision if config.mixed_precision != "no" else None,
        log_with="tensorboard",
        project_dir=config.output_dir
    )
    
    if config.seed is not None:
        set_seed(config.seed)
        
    info(f"Starting training process for {config.output_name}")
    
    # Load Models
    model_path = ROOT / "models" / config.base_model_name
    if not model_path.exists():
        error(f"Base model not found: {model_path}")
        sys.exit(1)
        
    info(f"Loading base model from {model_path}...")
    
    pipeline_cls = import_model_class(config.model_type)
    # Load full pipeline to get components easily
    # In production, load components individually to save RAM
    pipeline = pipeline_cls.from_single_file(str(model_path), torch_dtype=torch.float32)
    
    if config.model_type == "sd3":
        unet = pipeline.transformer
    else:
        unet = pipeline.unet
        
    vae = pipeline.vae
    noise_scheduler = pipeline.scheduler
    
    # Text Encoders
    text_handler = TextEncoderHandler(config.model_type, accelerator.device)
    text_handler.load_from_pipeline(pipeline)
    
    # Cleanup pipeline to save memory
    del pipeline
    torch.cuda.empty_cache()

    # Freeze models
    vae.requires_grad_(False)
    for te in text_handler.text_encoders:
        te.requires_grad_(False)
    unet.requires_grad_(False)
    
    # Setup LoRA
    from peft import LoraConfig, get_peft_model
    
    target_modules = ["to_k", "to_q", "to_v", "to_out.0"]
    if config.model_type == "sdxl":
        # SDXL might need more modules or specific naming
        target_modules = ["to_k", "to_q", "to_v", "to_out.0", "add_k_proj", "add_v_proj"]
    elif config.model_type == "sd3":
        # SD3 Transformer modules
        # Usually 'to_q', 'to_k', 'to_v', 'to_out.0' in attention blocks
        # But structure is different. We'll use a broad pattern or default.
        # For now, let's try default linear layers if possible or specific ones.
        # SD3 uses 'context_embedder', 'linear', etc.
        # A safe bet for transformers is usually targeting linear layers in attn.
        target_modules = ["to_q", "to_k", "to_v", "to_out.0"] 
        
    unet_lora_config = LoraConfig(
        r=config.network_dim,
        lora_alpha=config.network_alpha,
        init_lora_weights="gaussian",
        target_modules=target_modules,
    )
    
    unet = get_peft_model(unet, unet_lora_config)
    unet.print_trainable_parameters()
    
    # Optimizer
    optimizer_cls = torch.optim.AdamW
    optimizer = optimizer_cls(
        unet.parameters(),
        lr=config.learning_rate,
        betas=(0.9, 0.999),
        weight_decay=1e-2,
        eps=1e-08,
    )
    
    # Dataset
    dataset = ImageCaptionDataset(str(ROOT / config.dataset_path), config.resolution)
    train_dataloader = torch.utils.data.DataLoader(
        dataset,
        batch_size=config.batch_size,
        shuffle=True,
        num_workers=0 # Windows often has issues with num_workers > 0 in simple scripts
    )
    
    # Prepare with Accelerator
    unet, optimizer, train_dataloader = accelerator.prepare(
        unet, optimizer, train_dataloader
    )
    
    # Move other models to device
    vae.to(accelerator.device, dtype=torch.float32)
    for te in text_handler.text_encoders:
        te.to(accelerator.device)
        
    # Training Loop
    num_update_steps_per_epoch = math.ceil(len(train_dataloader) / config.gradient_accumulation_steps)
    max_train_steps = config.max_train_epochs * num_update_steps_per_epoch
    
    info(f"Running training for {max_train_steps} steps...")
    
    global_step = 0
    for epoch in range(config.max_train_epochs):
        unet.train()
        for step, batch in enumerate(train_dataloader):
            with accelerator.accumulate(unet):
                # Convert images to latents
                pixel_values = batch["pixel_values"].to(dtype=torch.float32)
                
                with torch.no_grad():
                    latents = vae.encode(pixel_values).latent_dist.sample()
                    latents = latents * vae.config.scaling_factor
                    if config.mixed_precision == "fp16":
                        latents = latents.to(dtype=torch.float16)
                
                # Sample noise
                noise = torch.randn_like(latents)
                bsz = latents.shape[0]
                timesteps = torch.randint(0, noise_scheduler.config.num_train_timesteps, (bsz,), device=latents.device)
                timesteps = timesteps.long()
                
                noisy_latents = noise_scheduler.add_noise(latents, noise, timesteps)
                
                # Get text embeddings
                captions = batch["caption"]
                encoded_text = text_handler.encode(captions)
                
                # Prepare added conditions for SDXL
                added_cond_kwargs = {}
                if config.model_type == "sdxl":
                    # Simplified time ids: assuming no crop, original size = resolution
                    add_time_ids = compute_time_ids(
                        (config.resolution, config.resolution),
                        (config.resolution, config.resolution),
                        (0, 0),
                        accelerator.device,
                        latents.dtype
                    )
                    # Repeat for batch
                    add_time_ids = add_time_ids.repeat(bsz, 1)
                    
                    added_cond_kwargs = {
                        "text_embeds": encoded_text["pooled_prompt_embeds"],
                        "time_ids": add_time_ids
                    }
                
                # Predict noise
                model_pred = unet(
                    noisy_latents, 
                    timesteps, 
                    encoder_hidden_states=encoded_text["encoder_hidden_states"],
                    added_cond_kwargs=added_cond_kwargs
                ).sample
                
                # Compute loss
                # SDXL usually uses v-prediction or epsilon. Default is epsilon.
                target = noise
                # If v_prediction, target is different. Assuming epsilon for now.
                
                loss = F.mse_loss(model_pred.float(), target.float(), reduction="mean")
                
                accelerator.backward(loss)
                optimizer.step()
                optimizer.zero_grad()
            
            global_step += 1
            if global_step % 10 == 0:
                info(f"Epoch {epoch+1}, Step {global_step}, Loss: {loss.item():.4f}")
            
        info(f"Epoch {epoch+1} completed.")
        
        # Save checkpoint
        save_every = config.save_every_n_epochs or 1
        if (epoch + 1) % save_every == 0:
            save_path = Path(config.output_dir) / f"{config.output_name}-ep{epoch+1}.safetensors"
            # Save LoRA weights
            # Unwrap model
            unwrapped_unet = accelerator.unwrap_model(unet)
            # Save adapters
            unwrapped_unet.save_pretrained(save_path)
            info(f"Saved checkpoint to {save_path}")

    success("Training finished.")

if __name__ == "__main__":
    main()
