from pydantic import BaseModel, Field, model_validator
from typing import Optional, Literal, List, Union

class TrainingConfig(BaseModel):
    # --- Model Configuration ---
    base_model_name: str = Field(..., description="Filename of the base model in models/ directory")
    model_type: Literal["sd_legacy", "sdxl", "sd3"] = "sdxl"
    
    # --- Output Configuration ---
    output_name: str = Field(..., description="Name of the output file (without extension)")
    output_dir: str = "project/outputs"
    save_precision: Literal["float16", "bf16", "float32"] = "float16"
    save_every_n_epochs: Optional[int] = 1
    save_every_n_steps: Optional[int] = None
    save_model_as: Literal["safetensors", "ckpt", "diffusers", "diffusers_safetensors"] = "safetensors"
    
    # --- Network Configuration (LoRA/LoHa/LyCORIS) ---
    network_type: Literal["lora", "loha", "lycoris"] = "lora"
    network_dim: int = 32
    network_alpha: int = 16
    network_module: str = "networks.lora" # Default for kohya-ss
    network_args: Optional[List[str]] = None
    
    # --- Dataset Configuration ---
    dataset_path: str = "project/dataset"
    resolution: int = 1024
    batch_size: int = 1
    max_train_epochs: int = 10
    max_train_steps: Optional[int] = None
    
    # --- Basic Training ---
    learning_rate: float = 1e-4
    unet_lr: Optional[float] = None
    text_encoder_lr: Optional[float] = None
    lr_scheduler: str = "constant"
    lr_scheduler_num_cycles: int = 1
    lr_scheduler_power: float = 1.0
    lr_warmup_steps: int = 0
    lr_warmup_ratio: float = 0.0
    optimizer_type: str = "AdamW8bit"
    optimizer_args: Optional[List[str]] = None
    
    # --- Advanced Training ---
    mixed_precision: Literal["no", "fp16", "bf16"] = "fp16"
    gradient_accumulation_steps: int = 1
    gradient_checkpointing: bool = False
    seed: Optional[int] = None
    clip_skip: Optional[int] = None
    max_token_length: int = 75 # 75, 150, 225
    caption_extension: str = ".txt"
    caption_dropout_rate: float = 0.0
    caption_dropout_every_n_epochs: int = 0
    keep_tokens: int = 0
    min_snr_gamma: float = 0.0
    noise_offset: float = 0.0
    adaptive_noise_scale: float = 0.0
    multires_noise_iterations: int = 0
    multires_noise_discount: float = 0.0
    
    # --- SDXL/SD3 Specific ---
    train_text_encoder: bool = True
    no_half_vae: bool = False
    cache_latents: bool = True
    cache_latents_to_disk: bool = False
    
    # --- Metadata ---
    training_comment: Optional[str] = None
    metadata_title: Optional[str] = None
    metadata_author: Optional[str] = None
    metadata_description: Optional[str] = None
    metadata_license: Optional[str] = None
    metadata_tags: Optional[str] = None

    @model_validator(mode='after')
    def validate_config(self):
        # Resolution check
        if self.resolution % 64 != 0:
            raise ValueError(f"Resolution {self.resolution} must be divisible by 64.")
            
        # Network Alpha/Dim check
        if self.network_alpha > self.network_dim:
            pass
        if self.network_dim <= 0 or self.network_alpha <= 0:
            raise ValueError("Network dimension and alpha must be positive.")

        return self
