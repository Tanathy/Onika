import asyncio
import subprocess
import sys
import os
from pathlib import Path
from typing import Optional, Dict
from system.training.schema import TrainingConfig
from system.log import info, error, success
from system import coordinator_settings as cs

class TrainingJob:
    def __init__(self, config: TrainingConfig, job_id: str):
        self.config = config
        self.job_id = job_id
        self.status = "pending" # pending, running, completed, failed
        self.process: Optional[asyncio.subprocess.Process] = None
        self.log_file = Path(f"project/logs/train_{job_id}.log")

    async def start(self, root_path: Path):
        self.status = "running"
        info(f"Starting training job {self.job_id}...")
        
        # Here we would construct the command to run the training script.
        # Since we don't have the training script yet, we'll simulate or call a placeholder.
        # Ideally, we will implement a 'train.py' in system/training/scripts/ or similar.
        
        # For now, let's assume we will call a python script that we will write next.
        script_path = root_path / "system" / "training" / "train_process.py"
        
        # We pass the config as a json argument or file
        config_path = root_path / "project" / "logs" / f"config_{self.job_id}.json"
        with open(config_path, "w") as f:
            f.write(self.config.model_dump_json(indent=2))
            
        cmd = [
            sys.executable,
            str(script_path),
            "--config", str(config_path)
        ]
        
        # Ensure log directory exists
        self.log_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(self.log_file, "w") as log_f:
            try:
                # We use subprocess.Popen to run in background (but managed by this async task)
                # Actually, for async we might want asyncio.create_subprocess_exec
                self.process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=log_f,
                    stderr=log_f,
                    cwd=str(root_path)
                )
                
                await self.process.wait()
                
                if self.process.returncode == 0:
                    self.status = "completed"
                    success(f"Training job {self.job_id} completed successfully.")
                else:
                    self.status = "failed"
                    error(f"Training job {self.job_id} failed. Check logs at {self.log_file}")
                    
            except Exception as e:
                self.status = "failed"
                error(f"Exception during training job {self.job_id}: {e}")

    def stop(self):
        if self.process and self.status == "running":
            try:
                self.process.terminate()
                self.status = "cancelled"
                info(f"Training job {self.job_id} cancelled.")
            except Exception as e:
                error(f"Failed to stop job {self.job_id}: {e}")

class TrainingManager:
    def __init__(self):
        self.current_job: Optional[TrainingJob] = None
        self.job_counter = 0

    async def start_training(self, config: TrainingConfig, root_path: Path) -> str:
        if self.current_job and self.current_job.status == "running":
            raise Exception("A training job is already running.")
            
        self.job_counter += 1
        job_id = f"{self.job_counter:03d}"
        
        job = TrainingJob(config, job_id)
        self.current_job = job
        
        # Start in background
        asyncio.create_task(job.start(root_path))
        
        return job_id

    def get_status(self):
        if not self.current_job:
            return {"status": "idle"}
        return {
            "status": self.current_job.status,
            "job_id": self.current_job.job_id,
            "log_file": str(self.current_job.log_file)
        }

    def stop_training(self):
        if self.current_job:
            self.current_job.stop()
