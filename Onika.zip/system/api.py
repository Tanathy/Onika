from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pathlib import Path
from typing import List, Optional, Dict, Any
from pydantic import BaseModel
from fastapi import FastAPI, HTTPException
from system import coordinator_settings as cs
from system.context import MODEL_MANAGER, DATASET_MANAGER, TRAINING_MANAGER
from system.diffusion.detector import detect_model_type
from system.training.schema import TrainingConfig
from safetensors.torch import load_file, save_file
import json

app = FastAPI(title="Onika Trainer")

# We will set this in entry.py
ROOT_PATH = Path(".")

class CaptionUpdate(BaseModel):
    image_name: str
    caption: str

class MetadataUpdate(BaseModel):
    metadata: Dict[str, str]

@app.get("/api/status")
async def get_status():
    model_info = None
    if MODEL_MANAGER.loaded_model:
        model_info = MODEL_MANAGER.loaded_model.get_info()
    
    training_status = TRAINING_MANAGER.get_status()
    
    return {
        "status": "running", 
        "config": cs.SETTINGS, 
        "model": model_info,
        "training": training_status
    }

@app.get("/api/training/config")
async def get_training_config():
    config_path = ROOT_PATH / "config" / "training.json"
    if config_path.exists():
        try:
            with open(config_path, "r") as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading training config: {e}")
    
    # Return default from schema if file missing
    # We need to provide required fields for Pydantic instantiation
    return TrainingConfig(base_model_name="", output_name="default").model_dump()

@app.post("/api/training/config")
async def save_training_config(config: TrainingConfig):
    config_path = ROOT_PATH / "config" / "training.json"
    try:
        with open(config_path, "w") as f:
            json.dump(config.model_dump(), f, indent=4)
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/training/start")
async def start_training(config: TrainingConfig):
    try:
        job_id = await TRAINING_MANAGER.start_training(config, ROOT_PATH)
        return {"status": "success", "job_id": job_id}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/training/stop")
async def stop_training():
    TRAINING_MANAGER.stop_training()
    return {"status": "success", "message": "Training stopped"}

@app.get("/api/dataset/images")
async def list_dataset_images():
    return DATASET_MANAGER.get_images()

@app.post("/api/dataset/caption")
async def update_caption(data: CaptionUpdate):
    success = DATASET_MANAGER.update_caption(data.image_name, data.caption)
    if not success:
        raise HTTPException(status_code=400, detail="Failed to update caption. Check if image exists.")
    return {"status": "success", "caption": data.caption}

@app.get("/api/models")
async def list_models():
    models_dir = ROOT_PATH / "models"
    if not models_dir.exists():
        return []
    
    models = []
    for f in models_dir.glob("*"):
        if f.suffix in [".safetensors", ".ckpt"]:
            models.append({
                "name": f.name,
                "path": str(f),
                "type": detect_model_type(f)
            })
    return models

@app.get("/api/outputs")
async def list_outputs():
    outputs_dir = ROOT_PATH / "project" / "outputs"
    if not outputs_dir.exists():
        return []
    
    outputs = []
    for f in outputs_dir.glob("*.safetensors"):
        outputs.append({
            "name": f.name,
            "path": str(f)
        })
    return outputs

@app.get("/api/metadata/{filename}")
async def get_metadata(filename: str):
    # Look in outputs first, then models? Or just outputs?
    # User probably wants to edit their trained LoRAs.
    file_path = ROOT_PATH / "project" / "outputs" / filename
    if not file_path.exists():
        # Try models dir
        file_path = ROOT_PATH / "models" / filename
        if not file_path.exists():
            raise HTTPException(status_code=404, detail="File not found")
            
    try:
        # safetensors.safe_open allows reading metadata without full load
        from safetensors import safe_open
        metadata = {}
        with safe_open(file_path, framework="pt", device="cpu") as f:
            metadata = f.metadata()
        return metadata or {}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/metadata/{filename}")
async def update_metadata(filename: str, data: MetadataUpdate):
    file_path = ROOT_PATH / "project" / "outputs" / filename
    if not file_path.exists():
         # Try models dir
        file_path = ROOT_PATH / "models" / filename
        if not file_path.exists():
            raise HTTPException(status_code=404, detail="File not found")
            
    try:
        # To update metadata, we must read the file and save it again with new metadata.
        # This is heavy for large files.
        tensors = load_file(file_path)
        # Merge existing metadata?
        # safe_open metadata returns dict of strings
        
        # We overwrite with provided metadata. 
        # Note: save_file expects metadata values to be strings.
        save_file(tensors, file_path, metadata=data.metadata)
        return {"status": "success", "message": "Metadata updated"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/models/load/{model_name}")
async def load_model(model_name: str):
    models_dir = ROOT_PATH / "models"
    model_path = models_dir / model_name
    
    if not model_path.exists():
        raise HTTPException(status_code=404, detail="Model not found")
        
    try:
        MODEL_MANAGER.load_model(model_path)
        return {"status": "success", "message": f"Loaded {model_name}"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/models/unload")
async def unload_model():
    MODEL_MANAGER.unload_current()
    return {"status": "success", "message": "Model unloaded"}

# Serve UI
# We'll mount the static directory later or just serve index.html for root
@app.get("/")
async def read_index():
    index_path = ROOT_PATH / "ui" / "index.html"
    if index_path.exists():
        return FileResponse(index_path)
    return {"error": "UI not found"}

def init_app(root_path: Path):
    global ROOT_PATH
    ROOT_PATH = root_path
    
    # Mount static files if needed, e.g. for css/js
    ui_path = root_path / "ui"
    if ui_path.exists():
        app.mount("/ui", StaticFiles(directory=str(ui_path)), name="ui")
    
    # Mount project folder to serve images
    project_path = root_path / "project"
    if project_path.exists():
        app.mount("/project", StaticFiles(directory=str(project_path)), name="project")

    return app
