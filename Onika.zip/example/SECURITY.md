# Security Policy

## Supported Versions

Versions that are currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 23.2.x   | :white_check_mark: |
| < 23.1.x   | :x:                |

## Reporting a Vulnerability

Please open an issue if you discover a security issue.
