const API_BASE = "/api";

// --- TABS ---
function openTab(tabName) {
    // Hide all tab contents
    document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
    // Deactivate all tab buttons
    document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
    
    // Show target tab
    document.getElementById(`tab-${tabName}`).classList.add('active');
    // Activate target button (simple search by onclick attribute for now)
    document.querySelectorAll(`.tab-btn[onclick="openTab('${tabName}')"]`).forEach(el => el.classList.add('active'));

    if (tabName === 'metadata') {
        fetchOutputs();
    }
}

function openSubTab(tabName) {
    document.querySelectorAll('.sub-tab-content').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.sub-tab-btn').forEach(el => el.classList.remove('active'));
    
    document.getElementById(tabName).classList.add('active');
    document.querySelectorAll(`.sub-tab-btn[onclick="openSubTab('${tabName}')"]`).forEach(el => el.classList.add('active'));
}

// --- STATUS & LOGS ---
async function fetchStatus() {
    try {
        const res = await fetch(`${API_BASE}/status`);
        const data = await res.json();
        updateStatusUI(data);
    } catch (e) {
        console.error("Failed to fetch status", e);
    }
}

function updateStatusUI(data) {
    const statusEl = document.getElementById("system-status");
    const trainingStatusEl = document.getElementById("training-status");
    
    statusEl.textContent = data.status;
    
    if (data.training) {
        trainingStatusEl.textContent = data.training.status;
        const btnStart = document.getElementById("btn-start-train");
        const btnStop = document.getElementById("btn-stop-train");
        
        if (data.training.status === "running") {
            btnStart.disabled = true;
            btnStop.disabled = false;
            btnStart.textContent = "Training Running...";
        } else {
            btnStart.disabled = false;
            btnStop.disabled = true;
            btnStart.textContent = "Start Training";
        }
    }
}

// --- MODELS ---
async function fetchModels() {
    try {
        const res = await fetch(`${API_BASE}/models`);
        const models = await res.json();
        const select = document.getElementById("base_model_name");
        select.innerHTML = "";
        
        models.forEach(m => {
            const opt = document.createElement("option");
            opt.value = m.name;
            opt.textContent = `${m.name} (${m.type})`;
            opt.dataset.type = m.type;
            select.appendChild(opt);
        });
        
        // Auto-select type when model changes
        select.addEventListener("change", () => {
            const selectedOpt = select.options[select.selectedIndex];
            const type = selectedOpt.dataset.type;
            if (type && type !== "unknown") {
                document.getElementById("model_type").value = type;
            }
        });
        
        // Trigger change once to set initial type
        if (select.options.length > 0) {
            select.dispatchEvent(new Event('change'));
        }
    } catch (e) {
        console.error("Failed to fetch models", e);
    }
}

// --- TRAINING ---
function getTrainingFormData() {
    const form = document.getElementById("training-form");
    const formData = new FormData(form);
    const config = {};
    
    const numFields = [
        "network_dim", "network_alpha", "resolution", "batch_size", 
        "max_train_epochs", "save_every_n_epochs", "gradient_accumulation_steps", 
        "lr_warmup_steps", "seed", "clip_skip", "learning_rate", 
        "unet_lr", "text_encoder_lr", "min_snr_gamma", "noise_offset", 
        "adaptive_noise_scale", "multires_noise_iterations", "multires_noise_discount",
        "caption_dropout_rate", "caption_dropout_every_n_epochs", "keep_tokens"
    ];

    for (let [key, value] of formData.entries()) {
        if (numFields.includes(key)) {
            config[key] = value ? Number(value) : null;
        } else {
            config[key] = value;
        }
    }
    
    const checkboxes = form.querySelectorAll('input[type="checkbox"]');
    checkboxes.forEach(cb => {
        config[cb.name] = cb.checked;
    });
    
    return config;
}

async function loadTrainingConfig() {
    try {
        const res = await fetch(`${API_BASE}/training/config`);
        const config = await res.json();
        
        const form = document.getElementById("training-form");
        for (const [key, value] of Object.entries(config)) {
            const input = form.elements[key];
            if (input) {
                if (input.type === "checkbox") {
                    input.checked = value;
                } else {
                    input.value = value === null ? "" : value;
                }
            }
        }
    } catch (e) {
        console.error("Failed to load training config", e);
    }
}

async function saveTrainingConfig() {
    const config = getTrainingFormData();
    try {
        const res = await fetch(`${API_BASE}/training/config`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(config)
        });
        if (res.ok) {
            alert("Configuration saved!");
        } else {
            alert("Failed to save configuration.");
        }
    } catch (e) {
        alert(`Error saving config: ${e}`);
    }
}

async function startTraining() {
    const config = getTrainingFormData();

    try {
        const res = await fetch(`${API_BASE}/training/start`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(config)
        });
        const result = await res.json();
        if (res.ok) {
            alert(`Training started! Job ID: ${result.job_id}`);
            fetchStatus();
        } else {
            alert(`Error: ${result.detail}`);
        }
    } catch (e) {
        alert(`Error starting training: ${e}`);
    }
}

async function stopTraining() {
    if (!confirm("Are you sure you want to stop training?")) return;
    await fetch(`${API_BASE}/training/stop`, { method: "POST" });
    fetchStatus();
}

// --- METADATA EDITOR ---
async function fetchOutputs() {
    try {
        const res = await fetch(`${API_BASE}/outputs`);
        const files = await res.json();
        const select = document.getElementById("meta-file-select");
        
        // Keep the first option
        select.innerHTML = '<option value="">-- Select a file --</option>';
        
        files.forEach(f => {
            const opt = document.createElement("option");
            // Handle both string (legacy) and object formats
            const name = typeof f === 'string' ? f : f.name;
            opt.value = name;
            opt.textContent = name;
            select.appendChild(opt);
        });
    } catch (e) {
        console.error("Failed to fetch outputs", e);
    }
}

async function loadMetadata() {
    const filename = document.getElementById("meta-file-select").value;
    if (!filename) return;

    try {
        const res = await fetch(`${API_BASE}/metadata/${filename}`);
        if (!res.ok) throw new Error("Failed to load metadata");
        
        const data = await res.json();
        renderMetadataEditor(data);
        document.getElementById("meta-editor-area").style.display = "block";
    } catch (e) {
        alert(e.message);
    }
}

function renderMetadataEditor(metadata) {
    const container = document.getElementById("meta-fields");
    container.innerHTML = "";

    // We'll display common fields as inputs, and others as a JSON dump or key-value pairs
    // For simplicity, let's just list them all as key-value inputs
    
    for (const [key, value] of Object.entries(metadata)) {
        const div = document.createElement("div");
        div.className = "form-group";
        div.style.marginBottom = "5px";
        
        const label = document.createElement("label");
        label.textContent = key;
        label.style.fontSize = "0.8em";
        
        const input = document.createElement("input");
        input.type = "text";
        input.value = value;
        input.dataset.key = key;
        input.className = "meta-input";
        
        div.appendChild(label);
        div.appendChild(input);
        container.appendChild(div);
    }
}

async function saveMetadata() {
    const filename = document.getElementById("meta-file-select").value;
    if (!filename) return;

    const inputs = document.querySelectorAll(".meta-input");
    const metadata = {};
    
    inputs.forEach(input => {
        metadata[input.dataset.key] = input.value;
    });

    try {
        const res = await fetch(`${API_BASE}/metadata/${filename}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(metadata)
        });
        
        if (res.ok) {
            alert("Metadata saved successfully!");
        } else {
            alert("Failed to save metadata");
        }
    } catch (e) {
        alert("Error saving metadata: " + e);
    }
}

// --- INIT ---
document.addEventListener("DOMContentLoaded", () => {
    fetchStatus();
    fetchModels();
    setInterval(fetchStatus, 2000);

    document.getElementById("btn-start-train").addEventListener("click", startTraining);
    document.getElementById("btn-stop-train").addEventListener("click", stopTraining);
    document.getElementById("btn-save-config").addEventListener("click", saveTrainingConfig);
    
    loadTrainingConfig();
});

// Init
document.addEventListener("DOMContentLoaded", () => {
    fetchModels();
    fetchStatus();
    setInterval(fetchStatus, 2000);
    
    document.getElementById("btn-start-train").addEventListener("click", startTraining);
    document.getElementById("btn-stop-train").addEventListener("click", stopTraining);
    document.getElementById("btn-save-config").addEventListener("click", saveTrainingConfig);
    
    loadTrainingConfig();
});
